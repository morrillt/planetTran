
<div id="footer" class="group constrainer">
  <img src="/img/footer_stamp960.png" width="960" height="39" alt="PlanetTran Logo" />
  <div id="footer2">Copyright &copy; 2011, PlanetTran, Inc. All Rights Reserved.</div>
</div><!--/footer-->

<script type="text/javascript">
  $('body').noisy({
    intensity: 1,
    size: 200,
    opacity: 0.05,
    fallback: '/img/page_background20.jpg',
    monochrome: true
  }).css('background-color', '#e5e7e4');
</script>
