<?php
/*
* Redirect people to the new index.php
*/
header("Refresh: 0; URL=https://secure.planettran.com/reservations/ptRes/index.php");
?>
