	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<link rel="stylesheet"  type="text/css" href="css.css"  />
	<link rel="stylesheet"  type="text/css" href="css1.css"  />
	<script language="JavaScript" type="text/javascript" src="functions.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	</head>
	<title>My Control Panel</title>
	<body>
	
<table border=0 id="main" height="100%" width="900px" align="center" cellspacing="0" cellpadding="0" >
  <tr width="100%">
    <td valign="bottom">
    
    
    
<!-- updated with new logo -->
<a href="http://www.planettran.com" border="0"><img align="left" src="images/planettran_logo_new.jpg" border="0" /></a>
<br clear="all" />
<!-- updated with new phone image -->
<div id="reservation-info" style="text-align: right;">
	<img src="images/phone-number.gif" alt="1 888 PLNT TRN (1 888 756 8876)" border="0" width="166" height="9" id="phone-number" style="float: none;margin-bottom: 9px;" />
</div>	
	
	
	
     </td>
  </tr>
  <tr>
    <td width="100%" height="1px"><div id="line"></div></td>
  </tr>
<tr>
<td>	<table width="100%" border="0" cellspacing="0" cellpadding="5" class="mainBorder">
	  <tr>
		<td class="mainBkgrdClr">
		  <h4 class="welcomeBack">Welcome Back, Seth</h4>
		  <p>
			<a href="index.php?logout=true" class="" style="" onmouseover="javascript: window.status='Log Out'; return true;" onmouseout="javascript: window.status=''; return true;">Log Out</a>
			|
			<a href="ctrlpnl_old.php" class="" style="" onmouseover="javascript: window.status='My Control Panel'; return true;" onmouseout="javascript: window.status=''; return true;">My Control Panel</a>
			|
			<a href="ctrlpnl.php?ui=old">Switch to Classic View</a>
		  </p>
		</td>
		<td class="mainBkgrdClr" valign="top" align="right">
		 <!--<div align="right">-->
		    <p>
			Thursday, April 09, 2009			</p>
			<p>
			  <a href="javascript: help();" class="" style="" onmouseover="javascript: window.status='Help'; return true;" onmouseout="javascript: window.status=''; return true;">Help</a>
			</p>
		  <!--</div>-->
		</td>
	  </tr>
	</table>
	</td>
</tr>
  <tr>
	    <td width="100%" height="26px"><div id="nav"><a href="ctrlpnl.php?active=home">Home</a><a href="impact.php">Impact</a><a href="ctrlpnl.php?active=schedules">Schedules</a><a href="ctrlpnl.php?active=view">Reservations</a><a href="ctrlpnl.php?active=locs">My Addresses</a><a href="receipts.php">Receipts</a><a href="referrals.php">Referrals</a><a href="register.php?edit=true">My Account</a><a href="info.php?active=service">Our Service</a><a href="ctrlpnl.php?active=qq">Price Quote</a><a href="map.php">Map</a></div></td>
  </tr>
	  <tr>
  <td height="200px" valign="top">
	<div class="basicText"><div class="titlebar">
Welcome to the PlanetTran Reservations System!  The following will links
will help you with setting up your account and booking reservations in a
fast, reliable, and convenient manner.</div>

<div class="bold13pt"><a href="impact.php">Impact</a></div> 
Get a report on how the usage of PlanetTran by you, your organization, 
and your referral network has decreased carbon emissions and fight
global warming!<br />  <br />
<div class="bold13pt"><a href="ctrlpnl.php?active=schedules">Schedules</a></div>
Create or change to an existing schedule that you manage.<br /> <br />

<div class="bold13pt"><a href="ctrlpnl.php?active=view">Reservations</a></div>
Create or change existing reservations for the current schedule (or,
"your schedule" if not an admin).<br /> <br />

<div class="bold13pt"><a href="ctrlpnl.php?active=locs">My Addresses</a></div>
Create or change your list of locations, which you choose when making
reservations.<br /> <br />

<div class="bold13pt"><a href="receipts.php">Receipts</a></div>
Get PDF receipts for individual trips, or a spreadsheet of activity for
a given time period.<br /> <br />

<div class="bold13pt"><a href="referrals.php">Referrals</a></div>
Refer friends and colleagues to PlanetTran, and see how their collective
usage decrease carbon emissions!<br /> <br />

<div class="bold13pt"><a href="register.php?edit=true">My Account</a></div>
Edit your profile (cell phone, email address, credit card) here.<br /> <br />

<div class="bold13pt"><a href="info.php?active=service">Our Service</a></div>
Get details about policies and procedures of the car service.<br /> <br />

<div class="bold13pt"><a href="ctrlpnl.php?active=qq">Price Quote</a></div>
Get rates from standard and arbitrary locations.<br /> <br />

<!--
<div class="bold13pt"><a href="">Mobile</a></div>
Learn how to create and modify reservations using any text capable
device! -->

	</div><p>&nbsp;</p>		</td>
	  </tr>
	</table>

		</body>
	</html>
	
