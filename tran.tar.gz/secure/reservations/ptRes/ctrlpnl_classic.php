<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
		"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
	<title>
	My Control Panel	</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<script language="JavaScript" type="text/javascript" src="functions.js"></script>
	<link href="css.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
	<h3 align="center">Administrator</h3>



	<!-- updated align and logo img -->
	<div align="left">
	<img src="images/planettran_logo_new.jpg" alt="reservations" vspace="5" />
	</div>	
	
	
	
	<table width="100%" border="0" cellspacing="0" cellpadding="5" class="mainBorder">
	  <tr>
		<td class="mainBkgrdClr">
		  <h4 class="welcomeBack">Welcome Back, Seth</h4>
		  <p>
			<a href="index.php?logout=true" class="" style="" onmouseover="javascript: window.status='Log Out'; return true;" onmouseout="javascript: window.status=''; return true;">Log Out</a>
			|
			<a href="ctrlpnl.php" class="" style="" onmouseover="javascript: window.status='My Control Panel'; return true;" onmouseout="javascript: window.status=''; return true;">My Control Panel</a>
			|
			<a href="ctrlpnl.php?ui=new"><h2>Try the new features of our latest release, Reservations 2.0!</h2></a>
		  </p>
		</td>
		<td class="mainBkgrdClr" valign="top">
		  <div align="right">
		    <p>
			Thursday, April 09, 2009			</p>
			<p>
			  <a href="javascript: help();" class="" style="" onmouseover="javascript: window.status='Help'; return true;" onmouseout="javascript: window.status=''; return true;">Help</a>
			</p>
		  </div>
		</td>
	  </tr>
	</table>
		<p>&nbsp;</p>
	<table width="100%" border="0" cellspacing="0" cellpadding="10" style="border: solid #CCCCCC 1px;">
	  <tr>
		<td bgcolor="#FAFAFA">
		  <form action="/reservations/ptRes/ctrlpnl.php" method="post">Search for FirstName: <input type="text" name="firstName"/> LastName: <input type="text" name="lastName"/> Email: <input type="text" name="email"><select name="group"><option value="">Select group</option><option value="1286">	Behrman Capital</option>
<option value="1270">	Oxford Bioscience Partners</option>
<option value="1238">%</option>
<option value="1064">15% off</option>
<option value="1324">406ventures</option>
<option value="1263">A123 Systems</option>
<option value="1327">Abbott</option>
<option value="68">ABCTMA</option>
<option value="1107">Abt</option>
<option value="1377">Abt Associates </option>
<option value="1442">Acadian Asset</option>
<option value="1303">Acambis</option>
<option value="1416">Acceleron Pharma</option>
<option value="1412">Acceleron Pharma-Shuttle</option>
<option value="1207">Accenture</option>
<option value="1413">Accenture-SF</option>
<option value="1157">Act  Now Productions</option>
<option value="1155">Adnexus</option>
<option value="1073">Adobe Systems</option>
<option value="1132">Advanced Technology Ventures</option>
<option value="1179">AER Worldwide</option>
<option value="1305">AgenCourt</option>
<option value="1086">Alantos</option>
<option value="1290">Allen Matkins</option>
<option value="1364">Alliance for Climate Protection</option>
<option value="49">Altus</option>
<option value="1423">AlwaysOn</option>
<option value="1154">AMAG</option>
<option value="1232">AMAGPHARMA</option>
<option value="1117">Apple</option>
<option value="1330">Apple Tree Partners</option>
<option value="1306">Apredica</option>
<option value="1054">Arcadia</option>
<option value="1076">Archemix</option>
<option value="4">Ariad</option>
<option value="1248">Ariston Pharmaceuticals</option>
<option value="1307">ArQule</option>
<option value="1308">ARS, Inc.</option>
<option value="1255">Ascend Consulting</option>
<option value="1261">Aspect Medical Systems Inc.</option>
<option value="1309">Associates of Cape Cod</option>
<option value="1131">Assurant</option>
<option value="1304">AstraZeneca</option>
<option value="1208">ATG</option>
<option value="1252">Athena Health</option>
<option value="1398">Atmel</option>
<option value="37">Audax</option>
<option value="1100">AVEO</option>
<option value="1302">Avid Technology </option>
<option value="1373">AviGenics, Inc</option>
<option value="1083">Aware Technologies</option>
<option value="1439">Axon Global</option>
<option value="1391">ayer</option>
<option value="1224">Babson Conf.2007(Comp)</option>
<option value="1326">BAE Systems</option>
<option value="38">Bain</option>
<option value="1400">Bain Capital</option>
<option value="1180">Barclays</option>
<option value="16">Barr Foundation</option>
<option value="1453">Benchmark Capital</option>
<option value="1143">Berkshire Partners</option>
<option value="1225">BFEI2007</option>
<option value="1246">BHCA</option>
<option value="1181">Bingham</option>
<option value="1388">Binnacle Capital Services</option>
<option value="1312">Bio-Rad Laboratories</option>
<option value="1424">BioConnections</option>
<option value="1457">BioEnergy </option>
<option value="22">Biogen</option>
<option value="1268">Biogen Idec</option>
<option value="1368">BioMarin Pharmaceutical</option>
<option value="1032">Biomed</option>
<option value="1000">Biomed Realty</option>
<option value="1314">Biomedical Research Models</option>
<option value="1315">BioProcessors</option>
<option value="1251">Biopure</option>
<option value="1210">BioScale</option>
<option value="32">BioTeam</option>
<option value="1316">BioTrove</option>
<option value="1150">Bloomberg</option>
<option value="1183">Blue Egg</option>
<option value="1317">Blue Sky Biotech</option>
<option value="1433">Body and Soul Magazine</option>
<option value="1338">Boston Area Rape Crisis Center</option>
<option value="1134">Boston Coach</option>
<option value="1209">Boston Consulting Group</option>
<option value="1285">Boston University</option>
<option value="1138">Brightcove</option>
<option value="1321">Bristol-Myers Squibb</option>
<option value="1370">BroadVision</option>
<option value="1269">Burns & Levinson LLP</option>
<option value="1318">Cambria BioSciences</option>
<option value="1039">Cambridge Associates</option>
<option value="54">Cambridge Associates - Kari Riley</option>
<option value="56">Cambridge Associates - M. Stapleton</option>
<option value="62">Cambridge Associates - MA</option>
<option value="55">Cambridge Associates - Malathi Gupta</option>
<option value="1112">Cambridge Associates-L. Smith</option>
<option value="1140">Cambridge Associates-Mark Evans</option>
<option value="1103">Cambridge College</option>
<option value="1347">Cape Wind</option>
<option value="1427">Carlson-Wagonlit</option>
<option value="26">CBI</option>
<option value="1065">CBRE-NE</option>
<option value="1229">CCE2007</option>
<option value="1141">CDM</option>
<option value="1147">CDM-Invoice</option>
<option value="1231">CEC2007(comp)</option>
<option value="1411">Cedar Tree Foundation</option>
<option value="1319">Cell Signaling Technology</option>
<option value="52">CERES</option>
<option value="1403">Cerimon Pharmaceuticals</option>
<option value="1387">CGPR</option>
<option value="1322">Charm Sciences</option>
<option value="1384">ChemGenes</option>
<option value="1221">Chileno Bay Club</option>
<option value="1279">Choate Hall & Stewart</option>
<option value="1266">ChoiceStream, Inc.</option>
<option value="1375">Christus Health</option>
<option value="33">CIC</option>
<option value="57">CIC-Tenant</option>
<option value="1158">CIEE</option>
<option value="1114">Cisco</option>
<option value="1441">Clean Air Task Force</option>
<option value="1254">Click Tactics, Inc.</option>
<option value="1336">ClimateCounts.org</option>
<option value="1274">Codon Devices Inc.</option>
<option value="1451">Cognizant</option>
<option value="1137">CombinatoRx</option>
<option value="1145">COMP</option>
<option value="1379">CRA International</option>
<option value="1380">Credit Suisse</option>
<option value="1250">Crossbeam Systems</option>
<option value="1349">Cubist Pharmaceuticals</option>
<option value="1397">Cubist Saturn</option>
<option value="1415">Cueball</option>
<option value="1408">CV Therapeutics</option>
<option value="1448">CW-Promo</option>
<option value="1026">Cystic Fibrosis Foundation</option>
<option value="47">David Stroh</option>
<option value="1363">Davis Polk & Wardwell</option>
<option value="21">Decision Quest</option>
<option value="58">Deloitte</option>
<option value="1081">Deloitte-SF</option>
<option value="7">Design Continuum</option>
<option value="1284">DLA Piper</option>
<option value="1060">Don Munoz</option>
<option value="1010">Doug Thompson Special</option>
<option value="1352">Draper Fisher Jurvetson</option>
<option value="1159">DST Health Solutions</option>
<option value="41">Dunkin' Brands</option>
<option value="67">Dunkin' Brands - Invoice</option>
<option value="1144">Dwell Magazine</option>
<option value="1153">Earth Tech</option>
<option value="1002">Earthwatch</option>
<option value="1135">EchoingGreen</option>
<option value="20">ECO</option>
<option value="35">Eco-Limo</option>
<option value="1280">Edwards Angell Palmer & Dodge LLP</option>
<option value="1110">EHDD Architecture</option>
<option value="1289">Electronics For Imaging Inc.</option>
<option value="1241">Elysium Digital</option>
<option value="25">Enanta</option>
<option value="1091">Energy Foundation</option>
<option value="1325">EnerNOC</option>
<option value="1273">Ensemble Discovery</option>
<option value="1048">Environmental Defense</option>
<option value="1102">Environmental Defense</option>
<option value="1118">ETIP</option>
<option value="1437">Exelixis</option>
<option value="1422">Exeter</option>
<option value="1161">Exponent</option>
<option value="1184">ExxonMobil</option>
<option value="1035">Finnegan</option>
<option value="1281">Fish & Richardson PC</option>
<option value="1082">Five Prime Therapeutics</option>
<option value="1162">Forest City</option>
<option value="1129">France Telecom R &D</option>
<option value="1089">FreestyleInteractive</option>
<option value="1420">Fresh, Inc.</option>
<option value="1123">Frog Design</option>
<option value="1333">FSG Social Impact Advisors</option>
<option value="1163">Galt & Co.</option>
<option value="1265">GameLogic, Inc.</option>
<option value="34">Gap</option>
<option value="1185">Gateway Management</option>
<option value="1186">GE Energy</option>
<option value="1096">Genentech</option>
<option value="1206">Generation IM</option>
<option value="1127">GenerationIM</option>
<option value="1">Genzyme</option>
<option value="1242">Genzyme Meetings</option>
<option value="65">Genzyme Shuttle</option>
<option value="1149">Georgantas</option>
<option value="1298">GeoSyntec Consultants</option>
<option value="1369">GI Partners</option>
<option value="1244">Gilead</option>
<option value="1311">Global 360</option>
<option value="1088">Global Business Network</option>
<option value="1187">Global Green</option>
<option value="1016">Gloucester--D. Cash</option>
<option value="1017">Gloucester--S. Yost</option>
<option value="1431">Going Green East</option>
<option value="1029">Goldman-Boston</option>
<option value="1257">Goodwin Procter LLP</option>
<option value="42">Google</option>
<option value="1247">Goulston & Storrs</option>
<option value="1258">Granite Telecommunications</option>
<option value="1164">Great Point Energy</option>
<option value="1122">Green Zebra</option>
<option value="1071">Grouper Networks</option>
<option value="1075">Grove Street</option>
<option value="1018">Gund Partnership</option>
<option value="27">Hadassah</option>
<option value="18">Hadassah</option>
<option value="1051">Hagen & Co.</option>
<option value="1345">Haley & Aldrich Inc.</option>
<option value="39">Harvard</option>
<option value="28">Harvard Biophysics</option>
<option value="1417">Harvard Catalyst-CTSC</option>
<option value="1418">Harvard-DCP</option>
<option value="1070">Harvard-Dept. of Visual & Environmental Studies</option>
<option value="1430">Harvard-EPS</option>
<option value="1058">Harvard-HMI</option>
<option value="1335">Harvard-LLF</option>
<option value="1001">Harvard-McLauglin</option>
<option value="1454">Harvard-MTA</option>
<option value="1419">Harvard-Systems Biology</option>
<option value="1124">Harvard: G. Demetri</option>
<option value="1245">HBS-GT</option>
<option value="1348">HBS-Reunions</option>
<option value="1211">HCP</option>
<option value="1099">HCP-CM</option>
<option value="1098">HCP-RD</option>
<option value="1165">Health Directions</option>
<option value="1264">Helicos BioSciences Corp.</option>
<option value="1287">Heller Ehrman LLP</option>
<option value="44">Hewlett Foundation</option>
<option value="1452">Hidary Foundation</option>
<option value="1362">HIG Capital</option>
<option value="1406">Hill & Knowlton</option>
<option value="1092">Histogenics</option>
<option value="70">Hotel @ MIT Shuttle</option>
<option value="1354">Howrey LLP</option>
<option value="1174">HSBC</option>
<option value="1390">HSDM</option>
<option value="14">HSPH</option>
<option value="1056">HSPH-IID</option>
<option value="19">HSPH-LB</option>
<option value="1355">Hummer Winblad Venture Partners</option>
<option value="1202">ICF</option>
<option value="1346">ICLEI</option>
<option value="6">Idenix</option>
<option value="1055">IDEO</option>
<option value="1063">IDEO - SF</option>
<option value="1414">Iderapharma</option>
<option value="1074">IFF</option>
<option value="48">Ignition Ventures</option>
<option value="1166">Industrial Logic</option>
<option value="1111">Infoscitex</option>
<option value="1167">Inspiritas</option>
<option value="1212">Institute for Global Communications</option>
<option value="1037">Interaction Inst.</option>
<option value="1204">InterMune</option>
<option value="1188">InterSystems</option>
<option value="1443">Intertek</option>
<option value="1296">InterWest Partners</option>
<option value="1182">Intuit</option>
<option value="11">Ipswitch</option>
<option value="1277">iRobot Corp.</option>
<option value="1151">Irving House</option>
<option value="1359">Isaacson, Miller</option>
<option value="1189">iSkoot</option>
<option value="1031">Jack Gorman</option>
<option value="1275">Jacobs Engineering Group Inc.</option>
<option value="1095">Javelin</option>
<option value="1203">jazz guest</option>
<option value="69">Jazz Pharma - Invoice</option>
<option value="1084">Jazz Pharmaceuticals</option>
<option value="1421">Jefferies & Company, Inc.</option>
<option value="1371">JH Partners LLC</option>
<option value="1139">Jobin-Leeds Partnership</option>
<option value="1205">JumpTap</option>
<option value="1168">Katzenbach Partners</option>
<option value="1356">Kleiner Perkins Caufield & Byers</option>
<option value="1119">KPCB</option>
<option value="1169">KPMG</option>
<option value="1227">KSG - 2007</option>
<option value="1228">KSG - 2007</option>
<option value="1382">Laird and Partners</option>
<option value="1220">Latham & Watkins</option>
<option value="43">Levi Strauss</option>
<option value="46">Lieberman Productions</option>
<option value="1235">Lincoln Institute of Land Policy</option>
<option value="17">Lipomed</option>
<option value="1381">LoJack</option>
<option value="1446">London Symphony Orchestra</option>
<option value="1226">Lynchpin Productions</option>
<option value="31">MA Conf. for Women</option>
<option value="1240">MA Conf. for women</option>
<option value="1115">Mascoma</option>
<option value="1190">Mass Green Energy</option>
<option value="1339">Mass High Tech Council</option>
<option value="1386">Massachusetts Port Authority</option>
<option value="1405">Mathematica Policy Research</option>
<option value="1249">Matrix Partners</option>
<option value="1396">McKinsey</option>
<option value="1090">McKinsey-BOS</option>
<option value="5">McKinsey-NAKC</option>
<option value="1192">McNamee Lawrence & Co</option>
<option value="1142">MDV - Mohr Davidow Ventures</option>
<option value="1213">Meditech</option>
<option value="1191">Meetinghouse</option>
<option value="1361">Menlo Ventures</option>
<option value="1276">Metabolix</option>
<option value="1106">Method</option>
<option value="1170">MFS</option>
<option value="1374">Millennium Pharmaceuticals</option>
<option value="63">Millipore</option>
<option value="1259">Mintz Levin Cohn Ferris Glovsky & Popeo PC</option>
<option value="1067">MIT</option>
<option value="1066">MIT-Anne Deveau</option>
<option value="1044">MIT-LW</option>
<option value="24">MIT-MP</option>
<option value="1085">MIT-Physics</option>
<option value="1057">MIT-President Office</option>
<option value="1428">MIT-Travel</option>
<option value="1059">MMAFIN</option>
<option value="1410">Momenta Pharmaceuticals</option>
<option value="1334">Monotype Imagining</option>
<option value="1193">Monsanto</option>
<option value="1323">Moore Foundation</option>
<option value="1432">Mott Philanthropic</option>
<option value="1455">MPM Capital</option>
<option value="59">MSH</option>
<option value="1394">MTS Health Partners</option>
<option value="1062">Museum of Science</option>
<option value="1458">NATAS</option>
<option value="1328">National Grid</option>
<option value="1108">Navigant</option>
<option value="1214">NESCAUM</option>
<option value="1436">NeuroMetrix</option>
<option value="1171">New Boston Fund</option>
<option value="1366">New Enterprise Associates</option>
<option value="1234">Next Event</option>
<option value="1429">NextLight Renewable Power</option>
<option value="40">NextStreet</option>
<option value="1376">Nixon Peabody LLP</option>
<option value="1288">Norwest Venture Partners</option>
<option value="1260">Nova Biomedical Corp.</option>
<option value="30">Novartis</option>
<option value="64">Novartis Shuttle</option>
<option value="1219">Novartis Vaccines & Diagnostics</option>
<option value="61">Novartis-JL</option>
<option value="1278">Nutter McClennen & Fish LLP</option>
<option value="1272">OctoPlus Inc.</option>
<option value="1310">OpenTV</option>
<option value="1105">PA Consulting</option>
<option value="45">Packard Foundation</option>
<option value="1049">Packard Foundation</option>
<option value="53">Palm</option>
<option value="1079">Pantera Capital </option>
<option value="1194">Parthenon</option>
<option value="1407">Partners In Health</option>
<option value="1392">PBH/ Dig It Eco-Festival</option>
<option value="1195">Pernod-Ricard</option>
<option value="1061">Pete Day</option>
<option value="1003">Pfizer</option>
<option value="1300">Philips Lifeline</option>
<option value="1395">Phillip Van Huesen - PVH</option>
<option value="8">PlanetTran</option>
<option value="1447">PlanetTran Corporate</option>
<option value="1104">Polaris</option>
<option value="1215">Portrait Software</option>
<option value="1128">Power Advocate</option>
<option value="1201">PPD</option>
<option value="1097">Predictive Bioscience</option>
<option value="1404">Product Stewardship</option>
<option value="1125">Proskauer</option>
<option value="1172">Prudential</option>
<option value="1389">PT-0</option>
<option value="1004">PT-10</option>
<option value="1015">PT-11</option>
<option value="1012">PT-12</option>
<option value="1023">PT-13</option>
<option value="1040">PT-13</option>
<option value="1019">PT-14</option>
<option value="1006">PT-15</option>
<option value="1013">PT-16</option>
<option value="1014">PT-17</option>
<option value="1042">PT-18</option>
<option value="1043">PT-19</option>
<option value="1030">PT-2</option>
<option value="1007">PT-20</option>
<option value="1036">PT-21</option>
<option value="1034">PT-22</option>
<option value="1022">PT-23</option>
<option value="1077">PT-24</option>
<option value="1008">PT-25</option>
<option value="1078">PT-26</option>
<option value="1025">PT-27</option>
<option value="1024">PT-28</option>
<option value="1028">PT-30</option>
<option value="1011">PT-31</option>
<option value="1005">PT-5</option>
<option value="1020">PT-8</option>
<option value="1021">PT018</option>
<option value="1069">PT_32</option>
<option value="1094">PT_33</option>
<option value="1109">PT_9</option>
<option value="1046">Pure Communications</option>
<option value="1198">PWC</option>
<option value="1130">Qinetiq</option>
<option value="1399">Quark Pharma</option>
<option value="23">Radcliffe-CC</option>
<option value="1383">Radi Medical Systems</option>
<option value="1438">Radius Pharmaceuticals</option>
<option value="1329">Raytheon</option>
<option value="29">RBA</option>
<option value="1293">Rearden SMB</option>
<option value="1367">RedHat Summit</option>
<option value="1196">Rhytec</option>
<option value="1372">Riverside Company</option>
<option value="1050">Roche</option>
<option value="1146">Ropes & Gray - San Fran</option>
<option value="1378">Rose Li Associates</option>
<option value="1425">Saatchi & Saatchi</option>
<option value="1101">Saint Mary's College of California</option>
<option value="1313">Sanofi-Aventis</option>
<option value="1243">Sappi Paper</option>
<option value="10">Sasaki</option>
<option value="1047">Schott</option>
<option value="1113">Schwab</option>
<option value="1087">Seaport</option>
<option value="1350">Selby Lane Enterprises</option>
<option value="1038">Sensitech</option>
<option value="1385">Serious Materials</option>
<option value="1435">SheerLine Associates</option>
<option value="1444">Sheraton Needham</option>
<option value="1052">Shire</option>
<option value="1353">Silver Lake Partners</option>
<option value="1445">Sirtris Pharmaceuticals</option>
<option value="1365">SMC E&M</option>
<option value="1294">Sofinnova Ventures</option>
<option value="1297">Squire Sanders & Dempsey LLP</option>
<option value="1320">Stanford</option>
<option value="1393">Stanford BioEngineering Guest</option>
<option value="1401">Stanford MS & E Guest</option>
<option value="1337">Stone & Youngberg LLC</option>
<option value="1358">Stone & Youngberg LLC - Big Bear</option>
<option value="1450">Strategic Offsites</option>
<option value="1282">Sullivan & Worcester LLP</option>
<option value="1291">Summit partners</option>
<option value="1041">Swimfish</option>
<option value="1253">Symmes Maini & McKee Associates</option>
<option value="1331">TCC Group</option>
<option value="1217">TeleAtlas</option>
<option value="1271">Terminal Exchange Systems</option>
<option value="1409">Texas Pacific Group</option>
<option value="1402">The Ad Club</option>
<option value="1301">The Ariel Group</option>
<option value="1456">The Knot</option>
<option value="60">The Natural Dentist</option>
<option value="1292">Thoma Cressey Bravo</option>
<option value="1173">Timberland</option>
<option value="1295">Timberland Meetings</option>
<option value="1343">Toth Brand Imaging</option>
<option value="1197">Traina PR</option>
<option value="999">TRETC-2006</option>
<option value="3">Trillium</option>
<option value="1299">TSG Consumer Partners</option>
<option value="1045">Tufts</option>
<option value="1053">Tufts Fletcher School</option>
<option value="1357">Tufts Univ - Tisch College</option>
<option value="12">UCS</option>
<option value="1341">UCS-Limo</option>
<option value="1133">UCSF</option>
<option value="1175">Unitarian</option>
<option value="1342">Verenium Corporation</option>
<option value="1256">Veroxity Technology Partners Inc.</option>
<option value="2">Vertex</option>
<option value="1148">Vertex Saturn</option>
<option value="66">Vertex Shuttle</option>
<option value="1267">Vertical Communications, Inc.</option>
<option value="1116">Veson</option>
<option value="1434">VHA Northeast</option>
<option value="1426">Virgin Limo</option>
<option value="1068">Virgin Mobile USA</option>
<option value="1230">Virgin Money</option>
<option value="1262">Vision-Sciences, Inc.</option>
<option value="1199">Volt</option>
<option value="1136">W5 Networks</option>
<option value="1237">WBUR Comp</option>
<option value="1236">WBUR Listeners</option>
<option value="1283">Weil Gotshal & Manges LLP</option>
<option value="1200">Wellington</option>
<option value="1121">Wells Fargo</option>
<option value="1344">Weston Presidio</option>
<option value="1351">Wikimedia</option>
<option value="1072">William McDonough + Partners</option>
<option value="1126">Williams-Sonoma</option>
<option value="50">Wilson-Sonsini</option>
<option value="1176">Windham Pros</option>
<option value="1033">WM-10</option>
<option value="1332">WolfBlock Public Strategies, LLC</option>
<option value="15">Wood's Hole</option>
<option value="51">WorldWinner</option>
<option value="1120">WSGC</option>
<option value="1440">Wyeth</option>
<option value="1340">Zigo</option>
<option value="36">Zipcar</option>
<option value="9">Zoran</option>
</select> <input type="submit"/><table width="100%" border="0" cellspacing="0" cellpadding="1" align="center">
  <tr>
    <td class="tableBorder">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr>
          <td colspan="1" class="tableTitle">
		    <a href="javascript: void(0);" onclick="showHideCpanelTable('schedule');">&#8250; Passenger Schedules</a>
		  </td>
		  <td align="right" class="tableTitle">
		  <input type="button" value="Create Passenger Schedule" onmouseup="schedule('c','','','','');" onmouseover="window.status='Create Passenger Schedule'; return true;" onmouseout="window.status=''; return true;">
		  		</td>
          <!--td class="tableTitle">
            <div align="right">
              <a href="javascript: help('my_schedule');" class="" style="color: #FFFFFF;" onmouseover="javascript: window.status='Help - ?'; return true;" onmouseout="javascript: window.status=''; return true;">?</a>
            </div>
          </td>-->
        </tr>
      </table>
      <div id="schedule" style="display: block">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr class="rowHeaders">
          <td width="20%">Passenger</td>
	  <td width="20%">email</td>
          <td width="20%">Company/Organization</td>
          <td width="8%">Dept. Code</td>
          <td width="11%">Phone</td>
          <td width="7%">View</td>
          <td width="7%">Modify</td>
          <td width="7%">Delete</td>
        </tr>
       <!-- <tr class="cellColor" style="text-align: center">
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=name&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending resource name'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=name&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending resource name'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=created&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending created time'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=created&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending created time'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=modified&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending last modified time'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=modified&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending last modified time'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>&nbsp;</td>
		  <td>&nbsp;</td>
		  <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>-->
                <tr class="cellColor"><td colspan="9" align="center"></td></tr>      </table>
	  </div>
    </td>
  </tr>
</table>
<p>&nbsp;</p><table width="100%" border="0" cellspacing="0" cellpadding="1" align="center">
  <tr>
    <td class="tableBorder">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr>
          <td colspan="1" class="tableTitle">
		    <a href="javascript: void(0);" onclick="showHideCpanelTable('reservation');">&#8250; Reservations for Seth Riney</a>
		  </td>
		  <td align="right" class="tableTitle">
		  			<input type="button" value="Create New Reservation" onmouseup="reserve('r','','','','');" onmouseover="window.status='Create New Reservation'; return true;" onmouseout="window.status=''; return true;">
		</td>
          <!--<td class="tableTitle">
            <div align="right">
              <a href="javascript: help('my_reservations');" class="" style="color: #FFFFFF;" onmouseover="javascript: window.status='Help - Reservations for'; return true;" onmouseout="javascript: window.status=''; return true;">?</a>
            </div>
          </td>-->
        </tr>
      </table>
      <div id="reservation" style="display: block">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr class="rowHeaders">
          <td width="7%">#</td>
          <td width="10%">Date</td>
		  <td width="10%">Scheduled for</td>
          <td width="10%">from Location</td>
		  <td width="10%">to Location</td>
          <td width="10%">Pickup Time</td>
          <td width="10%">Checking Bags?</td>
          <td width="19%">Flight Details</td>
          <td width="7%">Modify</td>
          <td width="7%">Delete</td>
        </tr>
       <!-- <tr class="cellColor" style="text-align: center">
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=date&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending date'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=date&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending date'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=name&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending resource name'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=name&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending resource name'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=startTime&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending start time'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=startTime&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending start time'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=endTime&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending end time'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=endTime&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending end time'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>
            <a href="/reservations/ptRes/ctrlpnl.php?order=created&amp;vert=DESC" class="" style="" onmouseover="javascript: window.status='Sort by descending created time'; return true;" onmouseout="javascript: window.status=''; return true;">[&#8211;]</a>
			&nbsp;&nbsp;
            <a href="/reservations/ptRes/ctrlpnl.php?order=created&amp;vert=ASC" class="" style="" onmouseover="javascript: window.status='Sort by ascending created time'; return true;" onmouseout="javascript: window.status=''; return true;">[+]</a>
          </td>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
		  <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>-->
                <tr class="cellColor0" align="center"><td>ABF0CA</td><td><a href="javascript: reserve('v','','','glb49d3b56abf0ca');" class="" style="" onmouseover="javascript: window.status='View this reservation'; return true;" onmouseout="javascript: window.status=''; return true;">04/12/2009</a>
</td><td style="text-align:left;">Seth Riney</td><td style="text-align:left;">Logan Int'l Airport</td><td style="text-align:left;">Hermsdorf Home</td><td>1:15pm</td><td>no</td><td style="text-align:left;">AA2062 13:20 from MIA</td><td><a href="javascript: reserve('m','','','glb49d3b56abf0ca');" class="" style="" onmouseover="javascript: window.status='Modify this reservation'; return true;" onmouseout="javascript: window.status=''; return true;">Modify</a>
</td>          <td><a href="javascript: reserve('d','','','glb49d3b56abf0ca');" class="" style="" onmouseover="javascript: window.status='Delete this reservation'; return true;" onmouseout="javascript: window.status=''; return true;">Delete</a>
</td></tr>
      </table>
	  </div>
    </td>
  </tr>
</table>
<p>&nbsp;</p><form name="aptSelect" action="/reservations/ptRes/ctrlpnl.php" method="GET" style="margin:0;">
<table width="100%" border="0" cellspacing="0" cellpadding="1" align="center">
  <tr>
    <td class="tableBorder">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr>
          <td class="tableTitle" colspan="1">
		    <a href="javascript: void(0);" onclick="showHideCpanelTable('permissions');">&#8250; Locations for Seth Riney</a>
		  </td>
		  <td align="right" valign="middle" class="tableTitle" width="30%">
		  <select name="apts" style="margin:0;">
		    <option value="">Add an Airport</option><option value="airport-BOS">Boston Logan Int'l</option><option value="airport-MHT">Manchester Int'l Airport</option><option value="airport-OAK">Oakland Int'l Airport</option><option value="airport-PVD">TF Green Int'l Airport</option><option value="airport-SFO">San Francisco Int'l</option><option value="airport-SJC">San Jose Int'l</option></select><input type="hidden" name="active" value="locs"><input type="submit" value="Add" name="add" style="margin:0;"></td><td align="right" class="tableTitle" width="10%"><input type="button" value="Create New Location" onmouseup="locate('c','','','','ssk425bec50e7f03');" onmouseover="window.status='Create New Location'; return true;" onmouseout="window.status=''; return true;">		</td>
        </tr>
      </table>
      <div id="permissions" style="display: block;">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr class="rowHeaders">
          <td width="10%">Location</td>
          <td width="10%">Address1</td>
          <td width="10%">Address2</td>
          <td width="10%">City</td>
		  <td width="5%">State</td>
		  <td width="5%">Zip</td>
		  <td width="10%">Cell Phone</td>
		  <td width="26%">Notes</td>
		  <td width="7%">Modify</td>
		  <td width="7%">Delete</td>
        </tr>
        <tr class="cellColor0">
<td>1 Memorial Dr.</td><td>1 Memorial Dr</td><td></td><td>Cambridge</td><td>MA</td><td>02142</td><td></td><td>corner of main and memorial drive</td><td align="center"><a href = "javascript: locate('m','glb48ad57793328a','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48ad57793328a','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>1 Seaport Blvd</td><td>1 Seaport Blvd</td><td></td><td>Boston</td><td>MA</td><td>02210</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb466080bb02a72','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb466080bb02a72','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>100 Summer St</td><td>100 Summer St</td><td></td><td>Boston</td><td>MA</td><td>02110</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46c5be173f45d','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46c5be173f45d','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>116 McGrath</td><td>116 Mcgrath Hwy</td><td></td><td>Somerville</td><td>MA</td><td>02143</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46e5fd5d134c1','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46e5fd5d134c1','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>156 Kelton St.</td><td>156 Kelton St</td><td></td><td>Allston</td><td>MA</td><td>02134</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb45d338c90c52e','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb45d338c90c52e','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>160 Federal St</td><td>160 Federal St</td><td></td><td>Boston</td><td>MA</td><td>02110</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb481b0c5060723','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb481b0c5060723','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>18 Lantern Road</td><td>18 Lantern Ln</td><td></td><td>Newton</td><td>MA</td><td>02459</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46012c6830888','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46012c6830888','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>189 W. Canton</td><td>189 W. Canton</td><td></td><td>Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4578d1b6445d6','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4578d1b6445d6','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>200 Clarendon St.</td><td>200 Clarendon St</td><td></td><td>Boston</td><td>MA</td><td>02116</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46911b2114e87','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46911b2114e87','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>255 Commonwealth Ave</td><td>255 Commonwealth Ave</td><td></td><td>Boston</td><td>MA</td><td>02116</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb479a6324ca29c','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb479a6324ca29c','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>26 Commonwealth Terrace</td><td>26 Commonwealth Terrace</td><td></td><td>Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb454f5a807c84d','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb454f5a807c84d','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>263 Brattle St.</td><td>263 Brattle St</td><td></td><td>Cambridge</td><td>MA</td><td>02138</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb483ee8936846c','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb483ee8936846c','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>32 Vassar Street</td><td>32 Vassar St</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48c7db39348da','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48c7db39348da','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>37 Lee St., #3, JP</td><td>37 Lee St</td><td>#3</td><td>Jamaica Plain</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb449b0f6b30d53','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb449b0f6b30d53','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>38 Sidney St.</td><td>38 Sidney St.</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb47e93b9252d85','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb47e93b9252d85','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>482A Columbus Ave.</td><td>482A Columbus Ave.</td><td></td><td>Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb44fcdffd445d4','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb44fcdffd445d4','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>500 Unicorn Park</td><td>500 Unicorn Park Dr</td><td></td><td>Woburn</td><td>MA</td><td>01801</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48ff2744cf017','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48ff2744cf017','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>62 Atherton Road</td><td>62 Atherton Road</td><td></td><td>Brookline</td><td>MA</td><td>02142</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46a49d7e951aa','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46a49d7e951aa','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>62 Fayette St.</td><td>62 Fayette St</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46d4c63c30ce1','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46d4c63c30ce1','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Abe and Louie's</td><td>793 Boylston St</td><td></td><td>Boston</td><td>MA</td><td>02116</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46f042eb8889f','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46f042eb8889f','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Back BAy location #2</td><td>257 Commonwealth Ave</td><td></td><td>Boston</td><td>MA</td><td>02116</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb467c7eeadf457','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb467c7eeadf457','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Back Bay Sheraton</td><td>39 Dalton St</td><td></td><td>Boston</td><td>MA</td><td>02199</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48f37b5a805b1','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48f37b5a805b1','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Backbay Location</td><td>240 Commonwealth Ave</td><td></td><td>Boston</td><td>MA</td><td>02116</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb467c5d889071e','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb467c5d889071e','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Bank of America Pavilion</td><td>290 Northern Ave</td><td></td><td>Boston</td><td>MA</td><td>02210</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46ba44d3c9ce2','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46ba44d3c9ce2','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Beth-Israel</td><td>Longwood Medical Area</td><td></td><td>Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb43d115717c842','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb43d115717c842','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Biogen</td><td>8 Cambridge Center</td><td></td><td>Cambridge</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb43f1e890186ff','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb43f1e890186ff','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>BMC</td><td>Mass Ave. at Harrison</td><td>South End</td><td>Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb43d115481d4df','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb43d115481d4df','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Bob Vinci's House</td><td>240 Stratford St</td><td></td><td>West Roxbury</td><td>MA</td><td>02132</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb468951bc1a4ba','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb468951bc1a4ba','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Boston Coach</td><td>69 Norman St</td><td></td><td>Everett</td><td>MA</td><td>02149</td><td></td><td>take a left down the driver way at 69 Everett St.  Avoid the industrial chaos entrance</td><td align="center"><a href = "javascript: locate('m','glb46a03507728bc','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46a03507728bc','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Boston Convention Center</td><td>425 Summer St.</td><td></td><td>South Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb455e33e9f1b42','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb455e33e9f1b42','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Boston Logan Int'l</td><td></td><td></td><td>East Boston</td><td>MA</td><td>02129</td><td></td><td>http://www.massport.com/logan/getti_typeo_limou.html</td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor1">
<td>Brant Lake, NY</td><td></td><td></td><td>Brant Lake</td><td>NY</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb44fecb84e7f02','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb44fecb84e7f02','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Brigham & Women's</td><td>75 Francis St.</td><td></td><td>Boston</td><td>MA</td><td>02115</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb44fce0597ef53','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb44fce0597ef53','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Butcher Shop</td><td>552 Tremont St</td><td></td><td>Boston</td><td>MA</td><td>02118</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb46e5bb5b69eb4','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb46e5bb5b69eb4','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Charlie's Eatery</td><td>284 Newbury St</td><td></td><td>Boston</td><td>MA</td><td>02115</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4928cc5327b74','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4928cc5327b74','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Chart House</td><td>60 Long Wharf</td><td></td><td>Boston</td><td>MA</td><td>02110</td><td></td><td>behind Mariott Long Wharf</td><td align="center"><a href = "javascript: locate('m','glb474df723bbb91','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb474df723bbb91','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Children's Hospital</td><td>300 Longwood Ave</td><td></td><td>Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb449b0f4dcaa41','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb449b0f4dcaa41','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Children's Museum</td><td>300 Congress St</td><td></td><td>Boston</td><td>MA</td><td>02210</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb47a070154fef0','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb47a070154fef0','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>City of Cambridge</td><td>147 Hampshire St</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb462f60db32da5','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb462f60db32da5','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Copley Mariott</td><td>110 Huntington Ave</td><td></td><td>Boston</td><td>MA</td><td>02199</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48e51e7e674a4','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48e51e7e674a4','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Everett Garage</td><td>39 Mystic St</td><td></td><td>Everett</td><td>MA</td><td>02149</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb45eb76b1bdaff','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb45eb76b1bdaff','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Fleet Center</td><td>10 Canal St</td><td></td><td>Boston</td><td>MA</td><td>02114</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48f7d93625c84','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48f7d93625c84','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Garage</td><td>39 Mystic Street</td><td></td><td>Everett</td><td>MA</td><td>02149</td><td></td><td></td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor1">
<td>Genzyme Center</td><td>500 Kendall St</td><td></td><td>Cambridge</td><td>MA</td><td>02142</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48401301dfa92','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48401301dfa92','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Genzyme Science Center</td><td>49 New York Ave</td><td></td><td>Framingham</td><td>MA</td><td>01701</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4885655ce8cd3','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4885655ce8cd3','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Genzyme-Waltham</td><td>153 Second Ave.</td><td></td><td>Waltham</td><td>MA</td><td></td><td></td><td></td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor0">
<td>Hampton Inn</td><td>319 Speen St</td><td></td><td>Natick</td><td>MA</td><td>01760</td><td></td><td>Exit 13 off Mass Pike I-90</td><td align="center"><a href = "javascript: locate('m','glb4612bb5f6afaa','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4612bb5f6afaa','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>HBS</td><td>111 Western Ave</td><td></td><td>Allston</td><td>MA</td><td>02134</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb47a1e29555b88','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb47a1e29555b88','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>heinz Convention center</td><td>900 Boylston St</td><td></td><td>Boston</td><td>MA</td><td>02115</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48eff3960db2b','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48eff3960db2b','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Hermsdorf Home</td><td>15 Jefferson Rd</td><td></td><td>Winchester</td><td>MA</td><td>01890</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb49d3b3457ab2e','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb49d3b3457ab2e','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Home</td><td>17 Peters St.</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td>617-576-0996</td><td></td><td align="center"><a href = "javascript: locate('m','glb42b818899761d','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb42b818899761d','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Home</td><td>25 Stoneymeade Way</td><td></td><td>Acton</td><td>MA</td><td>01720</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb49454ef3af101','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb49454ef3af101','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Hotel @ MIT</td><td>20 Sidney St</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb459d2803353cd','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb459d2803353cd','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Hotel Commonwealth</td><td>500 Commonwealth Ave</td><td></td><td>Boston</td><td>MA</td><td>02215</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb483fe6c73368f','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb483fe6c73368f','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Hyatt Cambridge</td><td>575 Memorial Dr</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48640f44a656d','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48640f44a656d','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Isabella Stewart Garnder Museum</td><td>280 Fenway</td><td></td><td>Boston</td><td>MA</td><td>02115</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4929c1e1a6ea0','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4929c1e1a6ea0','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Johnny D's</td><td>17 Holland St</td><td></td><td>Somerville</td><td>MA</td><td>02144</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48eff347ed72d','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48eff347ed72d','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Liberty Hotel</td><td>215 Charles St</td><td></td><td>Boston</td><td>MA</td><td>02114</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4821d752ef0ee','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4821d752ef0ee','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Logan Int'l Airport</td><td></td><td></td><td>East Boston</td><td>MA</td><td>02128</td><td></td><td>Terminals A, B, C/D, and E are active.</td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor1">
<td>Manchester Int'l Airport</td><td>MHT</td><td></td><td>Manchester</td><td>NH</td><td>03103</td><td></td><td></td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor0">
<td>Mandarin Oriental</td><td>776 Boylston Street</td><td></td><td>Boston</td><td>MA</td><td>02199</td><td></td><td></td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor1">
<td>Mass. General</td><td>55 Fruit St</td><td></td><td>Boston</td><td>MA</td><td>02114</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48b701924fdf3','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48b701924fdf3','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>MHT</td><td>Manchester Airport</td><td></td><td>Manchester</td><td>NH</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4426bc1a7ef70','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4426bc1a7ef70','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>MiniLuxe</td><td>296 Newbury St</td><td></td><td>Boston</td><td>MA</td><td>02115</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4821d7772ecf3','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4821d7772ecf3','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Mount Auburn Hospital</td><td>Mount Auburn St.</td><td></td><td>Cambridge</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb43d1155af1b41','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb43d1155af1b41','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Musuem of Science</td><td>Science Park</td><td></td><td>Boston</td><td>MA</td><td>02114</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb47ee62c549e7c','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb47ee62c549e7c','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>New England Aquarium</td><td>1 Central Whrf</td><td></td><td>Boston</td><td>MA</td><td>02110</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4803706f92e2e','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4803706f92e2e','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Ocean Street Dock</td><td>Ocean Street Dock</td><td></td><td>Hyannis</td><td>MA</td><td>02601</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb468d1cf41a596','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb468d1cf41a596','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Office</td><td>1 Broadway</td><td></td><td>Cambridge</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb43cd5ed88b2a7','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb43cd5ed88b2a7','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Opera House</td><td>539 Washington St</td><td></td><td>Boston</td><td>MA</td><td>02124</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb481f872bc0acd','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb481f872bc0acd','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>other</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb45704fc4e30e1','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb45704fc4e30e1','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Pied Piper Ferry</td><td>278 Scranton Ave</td><td></td><td>Falmouth</td><td>MA</td><td>02540</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48a9c94eb93c7','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48a9c94eb93c7','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Pine Street Inn</td><td>444 Harrison Ave</td><td></td><td>Boston</td><td>MA</td><td>02118</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb492d3e895b325','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb492d3e895b325','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>PlanetTran-CA</td><td>900 Cherry Ave</td><td></td><td>San Bruno</td><td>CA</td><td>94066</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb45ac75f3b1d15','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb45ac75f3b1d15','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>PVD</td><td>Providence Airport</td><td></td><td>Providence</td><td>RI</td><td></td><td></td><td>Exit 13, I-95 South</td><td align="center"><a href = "javascript: locate('m','glb42b818abcaa41','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb42b818abcaa41','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Quincy Youth Arena</td><td>Sea St</td><td></td><td>Quincy</td><td>MA</td><td>02169</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb47db36e94f67a','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb47db36e94f67a','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Riney Home</td><td>17 Peters St</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4612bb998efa5','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4612bb998efa5','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Roble Hall</td><td>374 Santa Teresa St</td><td></td><td>Stanford</td><td>CA</td><td>94305</td><td></td><td></td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor0">
<td>Royal Sonesta Hotel</td><td>5 Cambridge Center</td><td></td><td>Cambridge</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb44242d3d5302f','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb44242d3d5302f','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>San Francisco Int'l</td><td>SFO</td><td></td><td></td><td>CA</td><td>94128</td><td></td><td></td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor0">
<td>San Jose Int'l</td><td>SJC</td><td></td><td></td><td>CA</td><td>95110</td><td></td><td></td><td align="center">Modify</td><td align="center">Delete</td><tr class="cellColor1">
<td>Somerset Club</td><td>42 Beacon St.</td><td></td><td>Boston</td><td>MA</td><td>02108</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb456f01c2d6db6','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb456f01c2d6db6','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>South End Buttery</td><td>314 Shawmut Ave</td><td></td><td>Boston</td><td>MA</td><td>02118</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4980d0c8119fa','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4980d0c8119fa','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>South Station</td><td>Summer Ave & Atlantic Ave</td><td></td><td>Boston</td><td>MA</td><td></td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb43b6b1ff641a1','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb43b6b1ff641a1','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Steamship Authority</td><td>1 Cowdry Rd</td><td></td><td>Woods Hole</td><td>MA</td><td>02543</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb48abe7bf20f1b','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb48abe7bf20f1b','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Super 8 San Bruno</td><td>421 El Camino Real</td><td></td><td>San Bruno</td><td>CA</td><td>94066</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb4681556d7e38e','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb4681556d7e38e','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Test</td><td>14 Ellery St</td><td></td><td>Cambridge</td><td>MA</td><td>02138</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb460ffeb247249','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb460ffeb247249','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor1">
<td>Toyota Watertown</td><td>Arsenal St</td><td></td><td>Watertown</td><td>MA</td><td>02472</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb461d5d1926b94','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb461d5d1926b94','','', 'ssk425bec50e7f03');"/a>Delete</td></tr><tr class="cellColor0">
<td>Whole Foods</td><td>340 River St</td><td></td><td>Cambridge</td><td>MA</td><td>02139</td><td></td><td></td><td align="center"><a href = "javascript: locate('m','glb492d3e531d753','','', 'ssk425bec50e7f03');"/a>Modify</td><td align="center"><a href = "javascript: locate('d','glb492d3e531d753','','', 'ssk425bec50e7f03');"/a>Delete</td></tr>      </table>
	  </div>
	  </td>
  </tr>
</table>
</form>
<p>&nbsp;</p><table width="100%" border="0" cellspacing="0" cellpadding="1" align="center">
  <tr>
    <td class="tableBorder">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr>
          <td class="tableTitle">
		    <a href="javascript: void(0);" onclick="showHideCpanelTable('quicklinks');">&#8250; Quick Links</a>
		  </td>
         <!-- <td class="tableTitle"><div align="right">
              <a href="javascript: help('quick_links');" class="" style="color: #FFFFFF" onmouseover="javascript: window.status='Help - Quick Links'; return true;" onmouseout="javascript: window.status=''; return true;">?</a>
            </div>
          </td>-->
        </tr>
      </table>
      <div id="quicklinks" style="display: block;">
      <table width="100%" border="0" cellspacing="1" cellpadding="0">
        <tr style="padding: 5px" class="cellColor">
          <td colspan="2">
            <p><b>&raquo;</b>
              <a href="http://www.planettran.com">PlanetTran Home</a>
            </p>
		<p><b>&raquo;</b>
               <a href="http://www.planettran.com/service.php">Details about Our Service</a>
             </p>
            <!--<p><b>&raquo;</b>
              <a href="schedule.php" class="" style="" onmouseover="javascript: window.status='Go to the Online Scheduler'; return true;" onmouseout="javascript: window.status=''; return true;">Go to the Online Scheduler</a>
            </p>-->
            <p><b>&raquo;</b>
              <a href="register.php?edit=true" class="" style="" onmouseover="javascript: window.status='Change My Profile Information/Password'; return true;" onmouseout="javascript: window.status=''; return true;">Change My Profile Information/Password</a>
            </p>
            <p><b>&raquo;</b>
              <a href="my_email.php" class="" style="" onmouseover="javascript: window.status='Manage My Email Preferences'; return true;" onmouseout="javascript: window.status=''; return true;">Manage My Email Preferences</a>
            </p>
            <p><b>&raquo;</b>
             <a href="javascript: window.open('feedback.php', 'feedbackForm', 'width=700, height=425'); void(0);">Send Feedback</a> 
            </p>
            <p><b>&raquo;</b>
             <a href="javascript: window.open('qq.php', 'qq', 'width=650, height=400, scrollbars=1'); void(0);">Get a Custom Quote w/ your organization's discount.</a> 
            </p>
            <p><b>&raquo;</b> <a href="admin.php?tool=schedules" class="" style="" onmouseover="javascript: window.status='Manage Schedules'; return true;" onmouseout="javascript: window.status=''; return true;">Manage Schedules</a>
</p>
<p><b>&raquo;</b> <a href="admin.php?tool=resources" class="" style="" onmouseover="javascript: window.status='Manage Resources'; return true;" onmouseout="javascript: window.status=''; return true;">Manage Resources</a>
</p>
<p><b>&raquo;</b> <a href="admin.php?tool=users" class="" style="" onmouseover="javascript: window.status='Manage Users'; return true;" onmouseout="javascript: window.status=''; return true;">Manage Users</a>
</p>
<p><b>&raquo;</b> <a href="admin.php?tool=reservations" class="" style="" onmouseover="javascript: window.status='Manage Reservations'; return true;" onmouseout="javascript: window.status=''; return true;">Manage Reservations</a>
</p>
<p><b>&raquo;</b> <a href="blackouts.php" class="" style="" onmouseover="javascript: window.status='Manage Blackout Times'; return true;" onmouseout="javascript: window.status=''; return true;">Manage Blackout Times</a>
</p>
<p><b>&raquo;</b> <a href="admin.php?tool=email" class="" style="" onmouseover="javascript: window.status='Mass Email Users'; return true;" onmouseout="javascript: window.status=''; return true;">Mass Email Users</a>
</p>
<p><b>&raquo;</b> <a href="usage.php" class="" style="" onmouseover="javascript: window.status='Search Scheduled Resource Usage'; return true;" onmouseout="javascript: window.status=''; return true;">Search Scheduled Resource Usage</a>
</p>
<p><b>&raquo;</b> <a href="admin.php?tool=export" class="" style="" onmouseover="javascript: window.status='Export Database Content'; return true;" onmouseout="javascript: window.status=''; return true;">Export Database Content</a>
</p>
<p><b>&raquo;</b> <a href="stats.php" class="" style="" onmouseover="javascript: window.status='View System Stats'; return true;" onmouseout="javascript: window.status=''; return true;">View System Stats</a>
</p>
            <p><b>&raquo;</b>
              <a href="mailto:reservations@planettran.com?cc=" class="" style="" onmouseover="javascript: window.status='Send a non-technical email to the administrator'; return true;" onmouseout="javascript: window.status=''; return true;">Send Email Regarding Reservations</a>
            </p>
            <p><b>&raquo;</b>
              <a href="index.php?logout=true" class="" style="" onmouseover="javascript: window.status='Log Out'; return true;" onmouseout="javascript: window.status=''; return true;">Log Out</a>
            </p>
          </td>
        </tr>
      </table>
	  </div>
    </td>
  </tr>
</table>
<p>&nbsp;</p>		</td>
	  </tr>
	</table>
		<!--<p align="center"><a href="http://phpscheduleit.sourceforge.net">phpScheduleIt v1.0.0</a></p>-->
	</body>
	</html>
	