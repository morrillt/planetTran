#!/usr/local/bin/perl

print "0\n";
die;
