<?php

$sitePrefix = 'http://planettran.com';
$securePrefix = 'https://secure.planettran.com/reservations/ptRes';
$cookiePath = '.planettran.com';
