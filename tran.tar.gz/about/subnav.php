<?php require dirname(__FILE__).'/../config/paths.php'; ?>
<div id="subnav">
  <h2>In this section:</h2>
  <ul>
    <li class="sn1"><a href="<?php echo $sitePrefix ?>/about/">About</a></li>
    <li class="sn2"><a href="<?php echo $sitePrefix ?>/about/careers/">Careers</a></li>
    <li class="sn3"><a href="<?php echo $sitePrefix ?>/about/management/">Management</a></li>
  </ul>
</div><!-- /subnav -->
