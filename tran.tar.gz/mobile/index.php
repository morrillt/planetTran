<?php

header('Location: https://secure.planettran.com/reservations/ptRes/m.index.php');

?>

