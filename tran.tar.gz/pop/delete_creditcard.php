<div class="popover_content">

	<p>Are you sure you want to delete this credit card?  This action cannot be undone.</p>

</div>