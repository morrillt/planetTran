<div class="popover_content">
	<p>Are you sure you want to delete this location?  This action cannot be undone.</p>
  <form method="post" action="admin_update.php?fn=delResource">
    <input type="hidden" name="machid" value="<?php echo $_GET['machid'] ?>" />
  </form>
</div>
