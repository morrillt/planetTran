<div class="popover_content">
  <p>Are you sure you want to remove this driver from your favorites?</p>
  <form method="post" action="admin_update.php?fn=delFavDriver">
    <input type="hidden" name="memberid" value="<?php echo $_GET['memberid'] ?>" />
  </form>
</div>
