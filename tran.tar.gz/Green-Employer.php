<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Green Employer - PlanetTran</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="planettran.css" rel="stylesheet" type="text/css">
<meta name="description" content="As a Green Employer, Boston and San Francisco based PlanetTran is always looking for experienced drivers who seek to work for a company who uses a fleet of Hybrid Electric Cars exclusively to provide ground transportation to individuals and organizations alike.">
<meta name="keywords" content="Green Employer, Boston Green Employer, Green Employer Boston, San Francisco Green Employer, Green Employer San Francisco, Hybrid Electric Cars, Boston Hybrid Electric Cars, San Francisco Hybrid Electric Cars">
</head>

<body leftmargin="0" topmargin="10" marginwidth="0" marginheight="0">
<div align="center">
  <table width="600" border="0" cellpadding="0" cellspacing="0">
<?php include("header_nav.shtml"); ?>
    <tr>
	<td colspan="4" valign="top" class="bodytext">
	
<div id="main-content">
	<h2 class="page-header"><img border="0" alt="Drive For Us" src="images/header_driveforus.gif" width="578" height="47" /></h2>	
	<h3 class="page-subheader">We're a Green Employer. Drive for us!</h3>
	<div class="article">
		<h4>Coming Soon!</h4>
		<p>Details about open positions will be posted here soon!  In the meantime, send a resume to <a href="mailto:jobs@planettran.com">jobs@planettran.com</a>.</p>
	</div>
</div>

	
	
		</td>
     </tr>
	<?php include("footer.shtml"); ?>
  </table>
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-6290296-1");
pageTracker._trackPageview();
</script>
</body>
</html>
