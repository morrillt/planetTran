<?php

include 'api.base.php';

initialize(true);

?>