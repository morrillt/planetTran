<?php

phpinfo();


/*
$str = "Arrival level under Frontier/Midwest signs";
$str = "arrival level, far right under United doors 3&4";
$str = "Arrival level, center island to the right, limo stand";
$str = "PlanetTran driver: Konstantinia, 617-999-9999, Meet and greet @ ".$str;
$num = strlen($str);

include('lib/DBEngine.class.php');

?>
<html><head><title>test page</title>
</head><body>
<form name="testfrm" action="test.php" method="post">
<div style="background-color: yellow;">erwg</div>
<div id="test">
<input type="checkbox" id="greet" name="test" checked>
</div>
<div style="background-color: yellow;">erwg</div>
<input type="submit" value="submit">
</form>
<script type="text/javascript">
	var a = document.getElementById('test');
	a.style.display= 'none';
	//a.checked = true;
</script>
<pre>
<? print_r($_POST); ?>
<?=$str?><br>
<?=$num?>
</pre>
<?

*/
?>
</body>
</html>
