<?php

$at = array();
$at['BOS'] = 
"Logan Airport meeting places: Terminal A: Arrivals level, outer surface lot area. Terminal B: US Airways, departure level, curbside. American Airlines departure level, curbside. Terminal C: Departure Level, outermost curb area. Terminal E: Arrivals Level, outermost curb area.";

$at['MHT'] =
"Meet your driver at baggage claim. The driver will be holding a sign with your last name or company name.";

$at['PVD'] = 
"Meet your driver downstairs at baggage claim, at bottom of escalator. (Driver will be holding a sign with your last name or company name).";

$at['SFO'] = 
"For domestic flights, employees will meet PlanetTran drivers at their airline's baggage claim area. For international flights, JetBlue, Spirit, and Virgin, passengers will meet the drivers at the limo stand outside of the customs exit. Drivers will carry a sign bearing the customer's name, and further coordination can be made by cell phone. Passengers may request a curbside pick-up in advance by telephone or through the online reservations system.";

$at['OAK'] = 
"Passengers will meet PlanetTran drivers at their airline's baggage claim area. Each driver will carry a sign bearing the customer's name, and further coordination can be made by cell phone. Passengers may request a curbside pick-up in advance by telephone or through the online reservations system.";

$at['SJC'] = 
"Passengers will meet PlanetTran drivers at their airline's baggage claim area. Each driver will carry a sign bearing the customer's name, and further coordination can be made by cell phone. Passengers may request a curbside pick-up in advance by telephone or through the online reservations system.";

//echo "<pre>";
//print_r($at);
//echo "</pre>";
?>
