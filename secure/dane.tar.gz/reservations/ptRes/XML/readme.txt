D I S C L A I M E R                                                                                          
WARNING: ANY USE BY YOU OF THE SAMPLE CODE PROVIDED IS AT YOUR OWN RISK.                                                                                   
Authorize.Net provides this code "as is" without warranty of any kind, either express or implied, including but not limited to the implied warranties of merchantability and/or fitness for a particular purpose.   
Authorize.Net owns and retains all right, title and interest in and to the Customer Information Manager intellectual property.



NOTES:


Before running this sample code you will need to:

1. update the login / transaction key information in vars.php.
2. check the api url in vars.php.


The code uses SimpleXML. http://us.php.net/manual/en/book.simplexml.php 
There are also other ways to parse xml in PHP depending on the version and what is installed.

